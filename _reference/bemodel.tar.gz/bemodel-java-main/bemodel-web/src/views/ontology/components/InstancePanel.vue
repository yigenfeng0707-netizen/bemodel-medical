<template>
  <el-card>
    <div class="filter-bar">
      <el-select v-model="conceptCode" filterable style="width: 260px" @change="load">
        <el-option
          v-for="c in conceptStore.concepts"
          :key="c.code"
          :label="`${c.name}（${c.code}）`"
          :value="c.code"
        />
      </el-select>
    </div>
    <el-alert
      type="info"
      :closable="false"
      title="实例通过「概念-物理表映射」从产品库实时反查，状态码已经值字典翻译成标准口径"
      style="margin-bottom: 12px"
    />
    <div v-loading="loading">
      <template v-if="data">
        <div class="inst-header">
          <b>{{ data.conceptName }}（{{ data.conceptCode }}）</b>
          <span class="inst-def">{{ data.definition }}</span>
          <el-tag size="small" effect="plain">{{ data.sourceCount }} 个来源库表</el-tag>
        </div>
        <el-card
          v-for="src in data.sources"
          :key="`${src.dsCode}.${src.tableName}`"
          class="source-card"
          shadow="never"
          v-loading="src.loading"
        >
          <template #header>
            <el-badge :value="`共 ${src.totalRows} 行`" type="primary">
              <span class="source-title">{{ src.dsCode }}.{{ src.tableName }}</span>
            </el-badge>
          </template>
          <el-table :data="src.instances" size="small" border max-height="420">
            <el-table-column
              v-for="col in Object.keys(src.instances[0] || {})"
              :key="col"
              :prop="col"
              :label="col"
              min-width="110"
              show-overflow-tooltip
            />
            <el-table-column label="操作" width="90" fixed="right">
              <template #default="{ row }">
                <el-button
                  v-if="resolveInhosNo(row)"
                  link
                  type="primary"
                  size="small"
                  @click="exportPatientRdf(resolveInhosNo(row))"
                >导出RDF</el-button>
                <span v-else>-</span>
              </template>
            </el-table-column>
          </el-table>
          <el-empty v-if="!src.instances.length" description="无实例数据" :image-size="40" />
          <el-pagination
            v-if="src.totalRows > 0"
            class="source-pager"
            small
            layout="total, prev, pager, next"
            :current-page="sourcePages[srcKey(src)] || 1"
            :page-size="pageSize"
            :total="src.totalRows"
            @current-change="(p) => loadSourcePage(src, p)"
          />
        </el-card>
        <el-empty v-if="!data.sources.length" description="该概念暂无物理映射，无法反查实例" />
      </template>
    </div>
  </el-card>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { listInstances } from '../../../api/ontology'
import { listFlowPatients } from '../../../api/flow'
import { exportPatientRdf } from '../../../api/rdf'
import { useConceptStore } from '../../../store/concept'

const conceptStore = useConceptStore()

const conceptCode = ref('FEE_DETAIL')
const pageSize = 20
const data = ref(null)
const loading = ref(false)
// 每个来源表独立翻页：key 为 dsCode.tableName
const sourcePages = ref({})

const srcKey = (src) => `${src.dsCode}.${src.tableName}`

// 住院患者名录：PATIENT 概念实例行没有住院号字段，按 姓名|性别|年龄 反查
const inpatients = ref([])

const inpByKey = computed(() => {
  const m = new Map()
  for (const p of inpatients.value) m.set(`${p.patient_name}|${p.sex}|${p.age}`, p.inhos_no)
  return m
})

const inpByName = computed(() => {
  const m = new Map()
  for (const p of inpatients.value) {
    if (!m.has(p.patient_name)) {
      m.set(p.patient_name, p.inhos_no)
    } else if (m.get(p.patient_name) !== p.inhos_no) {
      m.set(p.patient_name, null) // 重名，无法唯一确定
    }
  }
  return m
})

// 实例行 → 住院号：优先行内的住院号字段（如 INP_VISIT 概念），
// PATIENT 概念行用姓名/性别/年龄匹配住院患者名录；都拿不到则不显示导出入口
const resolveInhosNo = (row) => {
  const direct = row['住院号'] ?? row.inhos_no ?? row.inhosNo
  if (direct && direct !== '-') return direct
  if (conceptCode.value !== 'PATIENT' || !row['姓名']) return ''
  const byKey = inpByKey.value.get(`${row['姓名']}|${row['性别']}|${row['年龄']}`)
  if (byKey) return byKey
  return inpByName.value.get(row['姓名']) || ''
}

const load = async () => {
  if (!conceptCode.value) return
  loading.value = true
  try {
    data.value = await listInstances(conceptCode.value, { pageNum: 1, pageSize })
    sourcePages.value = {}
    if (conceptCode.value === 'PATIENT' && !inpatients.value.length) {
      inpatients.value = (await listFlowPatients(undefined, 1, 200)).list
    }
  } finally {
    loading.value = false
  }
}

// 单个来源表翻页：带 tableName 调接口，只刷新该表数据
const loadSourcePage = async (src, page) => {
  src.loading = true
  try {
    const res = await listInstances(conceptCode.value, {
      tableName: src.tableName,
      pageNum: page,
      pageSize
    })
    const updated = (res.sources || []).find(
      (s) => s.dsCode === src.dsCode && s.tableName === src.tableName
    )
    if (updated) {
      src.instances = updated.instances
      src.totalRows = updated.totalRows
    }
    sourcePages.value = { ...sourcePages.value, [srcKey(src)]: page }
  } finally {
    src.loading = false
  }
}

onMounted(() => {
  conceptStore.fetchAll()
  load()
})
</script>

<style scoped>
.filter-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.inst-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.inst-def {
  font-size: 12px;
  color: #909399;
  flex: 1;
}

.source-card {
  margin-bottom: 16px;
}

.source-title {
  font-size: 14px;
  font-weight: 600;
  margin-right: 16px;
}

.source-pager {
  margin-top: 12px;
  justify-content: flex-end;
}
</style>
